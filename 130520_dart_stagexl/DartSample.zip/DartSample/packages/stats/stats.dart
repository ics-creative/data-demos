library fpsstats;

import 'dart:html';
import 'dart:math';

part 'src/stats.dart';
