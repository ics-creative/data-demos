part of stagexl;

class KeyLocation {
  
  static const int STANDARD = 0;
  static const int LEFT = 1;
  static const int RIGHT = 2;
  static const int NUM_PAD = 3;
  static const int D_PAD = 4;
}
