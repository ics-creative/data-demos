part of stagexl;

class EventPhase {
  
  static const int CAPTURING_PHASE = 1;
  static const int AT_TARGET = 2;
  static const int BUBBLING_PHASE = 3;
}

