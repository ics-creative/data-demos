part of stagexl;

abstract class BitmapDrawable {
  
  void render(RenderState renderState);
}
