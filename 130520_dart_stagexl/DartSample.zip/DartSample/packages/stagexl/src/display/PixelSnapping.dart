part of stagexl;

class PixelSnapping {
  
  static const String NEVER = "never";
  static const String ALWAYS = "always";
  static const String AUTO = "auto";
}
