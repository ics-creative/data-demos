part of stagexl;

class CapsStyle
{
  static const String BUTT = "butt";
  static const String ROUND = "round";
  static const String SQUARE = "square";
}
