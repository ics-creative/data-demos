part of stagexl;

class JointStyle {
  
  static const String MITER = "miter";
  static const String ROUND = "round";
  static const String BEVEL = "bevel";
}
