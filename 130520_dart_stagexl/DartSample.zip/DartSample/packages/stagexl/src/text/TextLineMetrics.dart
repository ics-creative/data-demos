part of stagexl;

class TextLineMetrics {
  
  num ascent;
  num descent;
  num height;
  num leading;
  num width;
  num x;

  TextLineMetrics(this.x, this.width, this.height, this.ascent, this.descent, this.leading);
}
