part of stagexl;

class TextFieldAutoSize {
  
  static const String CENTER = "center";
  static const String LEFT = "left";
  static const String NONE = "none";
  static const String RIGHT = "right";
}
