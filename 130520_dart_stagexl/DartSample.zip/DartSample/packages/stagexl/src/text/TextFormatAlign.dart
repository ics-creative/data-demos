part of stagexl;

class TextFormatAlign {
  
  static const String CENTER = "center";
  static const String END = "end";
  static const String JUSTIFY = "justify";
  static const String LEFT = "left";
  static const String RIGHT = "right";
  static const String START = "start";
}
