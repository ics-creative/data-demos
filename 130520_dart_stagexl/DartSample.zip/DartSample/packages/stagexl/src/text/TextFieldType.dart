part of stagexl;

class TextFieldType {
  
  static const String DYNAMIC = "dynamic";
  static const String INPUT = "input";
}
