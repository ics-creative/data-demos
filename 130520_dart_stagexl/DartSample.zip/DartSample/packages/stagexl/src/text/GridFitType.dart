part of stagexl;

class GridFitType {
  
  static const String NONE = "none";
  static const String PIXEL = "pixel";
  static const String SUBPIXEL = "subpixel";
}
