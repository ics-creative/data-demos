part of stagexl;

class TextureAtlasFormat {
  
  static const String JSON = "json";
  static const String JSONARRAY = "jsonarray";
  //static const String STARLING = "starling";
  //static const String COCOS2D = "cocos2d";
  //static const String TEXTUREPACKERXML = "texturepackerxml";
}
