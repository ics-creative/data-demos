part of stagexl;

class Circle {
  
  num x;
  num y;
  num radius;

  Circle(this.x, this.y, this.radius);
}
