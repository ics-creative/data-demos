part of stagexl;

abstract class Animatable {
  
  bool advanceTime(num time);
  
}
