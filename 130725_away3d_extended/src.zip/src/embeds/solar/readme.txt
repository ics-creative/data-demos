﻿These texture are not inclueded.
Please download from http://planetpixelemporium.com/earth.html

earth_ambient.jpg
earth_clouds.jpg
earth_diffuse.jpg
earth_normals.jpg
earth_specular.jpg
moon.jpg

