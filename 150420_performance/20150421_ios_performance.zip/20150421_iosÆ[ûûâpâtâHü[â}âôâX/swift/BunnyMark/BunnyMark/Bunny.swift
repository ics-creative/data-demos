//
//  Bunny.swift
//  BunnyMark
//
//  Created by ICS NOHARA on 2015/04/02.
//  Copyright (c) 2015年 ICS-NOHARA. All rights reserved.
//

import SpriteKit;

import Foundation

class Bunny {
    init(node:SKSpriteNode){
        self.node = node;
    }
    var speedY:CGFloat = 0;
    var speedX :CGFloat = 0;
    var gravity:CGFloat = 0;
    var spin:CGFloat = 0;
    
    var node: SKSpriteNode!;
}