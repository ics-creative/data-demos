//
//  FPS.swift
//  BunnyMark
//
//  Created by ICS NOHARA on 2015/04/09.
//  Copyright (c) 2015年 ICS-NOHARA. All rights reserved.
//

import SpriteKit
import Foundation

class FPS{
    
    var currentTime:NSDate;
    
    //	実行時間チェック
    var startTime:NSDate;
    var endTime:NSDate;
    
    //	FPSの更新確認用
    var updateTime:Double = 500;
    
    //	fpsチェック(updateTimeを超えないと0)
    var fps:Double;
    
    var frames:Double;
    
    var measured:Bool;
    
    var container:SKLabelNode;
    
    var measureStartTime:NSDate;
    var totalTime:Double;
    
    init() {
        currentTime = NSDate();
        measured = false;
        container = SKLabelNode();
        
        container.text = "FPS";
        
        measured = false;
        fps = 0;
        frames = 0;
        
        endTime = NSDate();
        
        measureStartTime = NSDate();
        totalTime = 0;
        startTime = NSDate();
        
    }
    
    func begin() {
        startTime = NSDate();
    }
    
    func end(){
        currentTime = NSDate();
        frames = frames + 1;
        
        var interval = currentTime.timeIntervalSinceDate(endTime);
        
        if(updateTime <= interval) {
            var dt:Double = (interval) / 1000.0;
            fps = frames / dt;
            endTime = currentTime;
            measured = true;
            frames = 0;
            
            container.text = String("\( floor( fps * 1000 )/1000  )") + "FPS";
        }
        totalTime = currentTime.timeIntervalSinceDate( measureStartTime );
    }
    
    func currentFps(){
        
    }
}