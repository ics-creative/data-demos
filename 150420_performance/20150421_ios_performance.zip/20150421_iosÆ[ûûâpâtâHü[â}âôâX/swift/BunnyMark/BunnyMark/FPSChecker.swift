//
//  FPSChecker.swift
//  BunnyMark
//
//  Created by ICS NOHARA on 2015/04/13.
//  Copyright (c) 2015年 ICS-NOHARA. All rights reserved.
//

import Foundation


class FPSChecker {
    
    private var framerates:[NSTimeInterval];
    private var checkTiming:NSTimeInterval;
    private var recentCount:Int;
    private var totalTime:NSTimeInterval;
    private var frameCount:Int;
    private var fpsText:String;
    private var fpsValue:Double;
    
    private var startTime:NSDate!;
    
    init(checkTiming:Double = 0.5,recentCount:Int = 3){
        
        framerates = [];
        self.checkTiming = checkTiming;
        self.recentCount = recentCount;
        self.totalTime = 0;
        self.frameCount = 0;
        self.fpsText = ""
        self.fpsValue =  0;
    }
    
    func begin() {
        startTime = NSDate();
    }
    
    func fps() -> Double
    {
        return fpsValue;
    }
    
    func getFPSText() -> String
    {
        return self.fpsText;
    }
    
    func finish(){
        
        frameCount++;
        totalTime += fabs( startTime.timeIntervalSinceNow );
        
        //１秒以上経過していれば
        if (totalTime >= checkTiming) {
            var framerate = NSTimeInterval( frameCount ) / (totalTime);
                
            framerates.append(framerate);
            
            totalTime = 0;
            frameCount = 0;
            fpsText = String(format:"%.2f", framerate);
            fpsValue = framerate;
            
            if( framerates.count > recentCount ) {
                framerates.removeAtIndex(0);
            }
        }
    }
    //フレームレートを取得
    func getMostRecentFrameRate() -> (CFloat){
        var total:NSTimeInterval = 0;
        for (var i = 0; i < framerates.count; i++) {
            total += framerates[i];
        }
        return CFloat(total) / CFloat(framerates.count);
    }
    
    func getMostRecentCount() -> Int {
        return framerates.count;
    }
    
    
    func calculated() -> Bool {
        return framerates.count >= recentCount ;
    }
}