//
//  GameScene.swift
//  test4
//
//  Created by ICS NOHARA on 2015/04/09.
//  Copyright (c) 2015年 ICS-NOHARA. All rights reserved.
//

import SpriteKit

class GameScene: SKScene {
    override func didMoveToView(view: SKView) {
        /* Setup your scene here */
        myLabel = SKLabelNode(fontNamed:"Chalkduster")
        myLabel.text = "Hello, World!";
        myLabel.fontSize = 20;
        myLabel.position = CGPoint(x:CGRectGetMidX(self.frame), y:CGRectGetMidY(self.frame));
        
        fps.begin();
        
        startLabel = SKLabelNode(fontNamed:"Chalkduster")
        startLabel.text = "Touch To Start!";
        startLabel.fontSize = 20;
        startLabel.position = CGPoint(x:CGRectGetMidX(self.frame), y:CGRectGetMidY(self.frame));
        
        self.addChild(startLabel);
        
    }
    var bunnys:[Bunny] = [];
    var fps:FPSChecker = FPSChecker();
    
    var myLabel:SKLabelNode!;
    var startLabel:SKLabelNode!;
    var exits:Bool = true;
    
    
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        /* Called when a touch begins */
        
        for touch in (touches as! Set<UITouch>) {
            exits = false;
        }
        
        if( !exits ) {
            startLabel.removeFromParent();
            self.addChild(myLabel);
            
            myLabel.zPosition = 1;
        }
    }
    func rand() -> CGFloat {
        return CGFloat(arc4random() % 10000) / CGFloat(10000.0);
    }
    
    override func update(currentTime: CFTimeInterval) {
        /* Called before each frame is rendered */
        
        if( exits ){
            return;
        }
        
        fps.finish();
        

        myLabel.text = String( bunnys.count) + " BUNNYS" + ", " + fps.getFPSText();
        
        if(fps.calculated() && fps.getMostRecentFrameRate() <= 30)
        {
            exits = true;
            
            var alert = UIAlertView();
            alert.title = "exit";
            alert.message = String( bunnys.count)  + " BUNNYS";
            alert.addButtonWithTitle("OK");
            alert.show()
            
            return ;
        }
        
        let screenRect: CGRect = self.view!.frame;
        
        let maxX = CGRectGetMaxX(screenRect);
        let maxY = CGRectGetMaxY(screenRect);
        
        let minX:CGFloat = CGRectGetMinX(screenRect);
        let minY:CGFloat = CGRectGetMinY(screenRect);
        
        var amount:Int = fps.fps() <= 40 ? 1 : 5;
        
        for i in 0...amount {
            let sprite = SKSpriteNode(imageNamed:"bunny.png")
            
            let bunny = Bunny(node:sprite);
            
            bunny.speedX = (rand() * 10) - 5;
            bunny.speedY = -(rand() * 10) ;
            sprite.zRotation = rand() - 0.5;
            
            var r = ( rand() + 0.5 ) / 2;
            sprite.size.width = sprite.size.width * r;
            sprite.size.height = sprite.size.height * r;
            bunnys.append(bunny);
            
            sprite.position.x = 0;
            sprite.position.y = maxY;
            
            sprite.alpha = rand() * 0.7 + 0.3;
            
            self.addChild(sprite);
            
        }
        
        let gravity:CGFloat = 0.5;
        
        fps.begin();
        
        for myBunny in bunnys{
            myBunny.node.position.x += 1.0;
            
            
            myBunny.node.position.x += myBunny.speedX;
            myBunny.node.position.y += myBunny.speedY;
            myBunny.speedY -= gravity;
            
            if (myBunny.node.position.x > maxX) {
                myBunny.speedX *= -1;
                myBunny.node.position.x = maxX;
            } else if (myBunny.node!.position.x < minX) {
                myBunny.speedX *= -1;
                myBunny.node.position.x = minX;
            }
            
            if (myBunny.node.position.y > maxY) {
                myBunny.speedY = 0;
                myBunny.node.position.y = maxY;
                
            } else if (myBunny.node.position.y < minY) {
                
                myBunny.speedY *= -0.85;
                myBunny.spin = (rand() - 0.5) * 0.2
                if (rand() > 0.5) {
                    myBunny.speedY =  rand() * 28;
                }
                
                myBunny.node.position.y = minY;
            }
        }
        
        
    }
    

}
