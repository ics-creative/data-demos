﻿using UnityEngine;
using System.Collections;

public class MyBunny : MonoBehaviour {
	
	public float speedY = 0.0f;
	public float speedX  = 0.0f; 
}
