﻿using UnityEngine;
using System.Collections;


public class Main : MonoBehaviour  {

	public Transform bunnySprite ;

	int frameCount;
	float nextTime;
	ArrayList bunnys  = new ArrayList();
	bool exit;
	 
	// Use this for initialization
	void Start () {
		print(Screen.width + ", " + Screen.height); 
		Application.targetFrameRate = 60;
		 
		// スケールを変更。
		// transform.localScale = new Vector2( scale.x, scale.x); //  yoko ni awaseru 
		exit = true ;
	}
	
	// Update is called once per frame
	void Update () {
		
		if (exit && Input.touchCount > 0 || Input.GetMouseButtonDown(0)  ) {
			exit = false; 
			Score.started = true;
			nextTime = Time.time + 1;  
		}
		 
		if (exit) { 
			return;
		} 

		frameCount++;
		
		Score.bunnyCount = bunnys.Count;   
		if ( Time.time >= nextTime ) {


			// 1秒経ったらFPSを表示
			Score.score = frameCount;  
			Debug.Log("FPS : " + frameCount);
			
			if( frameCount <=  30  ) {
				exit = true; 
				return ; 
			}

			frameCount = 0;
			nextTime += 1; 

		}
		
		int amount = frameCount  >= 40 ? 5 : 1;
		
		// 画面左下のワールド座標をビューポートから取得
		Vector2 min = Camera.main.ViewportToWorldPoint (new Vector2 (0, 0));
		
		// 画面右上のワールド座標をビューポートから取得
		Vector2 max = Camera.main.ViewportToWorldPoint (new Vector2 (1, 1));

		 
		for (int i = 0; i < amount ; i++) { 
			Vector3 position = new Vector3 (min.x,max.y, 0);

			 
			Transform clone = Instantiate(bunnySprite) as Transform   ;	  
			 
			MyBunny p = clone.GetComponent(typeof(MyBunny)) as MyBunny; 
			 
			p.speedX = Random.Range(-0.08f,0.08f); 
			p.speedY = Random.Range(0.0f,0.01f); 
			p.transform.Rotate(new Vector3(0.0f,0.0f,Random.Range(-20f,20f) ));

			float scale = Random.Range(0.5f,1.0f) * 1.5f ;  
			clone.localScale = new Vector3(scale,scale,1.0f);
			
			SpriteRenderer sr = clone.GetComponent(typeof(SpriteRenderer)) as SpriteRenderer;
			Color color = sr.color; 
			 color.a = Random.Range(0.3f,1.0f);
			sr.color = color;

			clone.position = new Vector3(min.x,max.y,0.0f );
			 
			bunnys.Add(p);  
			
		} 
		
		float gravity = 0.005f;

		for (int i = 0; i < bunnys.Count; i ++ ) {
			MyBunny myBunny = bunnys[i] as MyBunny;

			Vector2 position = new Vector2(myBunny.transform.position.x,myBunny.transform.position.y);  
	

			position.x = position.x + myBunny.speedX;
			position.y = position.y + myBunny.speedY;

			myBunny.speedY -= gravity;
			
			if (position.x > max.x) {
				myBunny.speedX *= -1;
				 position.x = max.x;
			} else if (position.x < min.x) {
				myBunny.speedX *= -1;
				position.x = min.x ;
			}
			
			if ( position.y > max.y) {
				myBunny.speedY = 0;
				position.y = max.y;
				
			} else if (position.y < min.y) {
				
				myBunny.speedY *= -0.85f ; 
				if (Random.Range(0.0f,1.0f) > 0.5f ) {
					myBunny.speedY = - Random.Range(0.0f,0.4f);  
				} 
				
				position.y = min.y ;
			}
			myBunny.transform.position = position; 
		}
	}
}
