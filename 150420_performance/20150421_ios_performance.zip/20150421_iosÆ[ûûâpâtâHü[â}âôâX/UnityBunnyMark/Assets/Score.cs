using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Score : MonoBehaviour {

 	 public  static int score = 0 ;
	public static int bunnyCount = 0;
	public static bool started = false;
	// Use this for initialization
	void Start () {

	}
	 
	// Update is called once per frame
	void Update () { 
		
		Text instruction = gameObject.GetComponent<Text> (); 

		if (started) {
			instruction.text = bunnyCount + " BUNNYS, " + Score.score + " FPS "; 
		} else {
			instruction.text = "Touch to Start";  
		}
	}
}
  