・メタデータを簡単に設定するパネルです。
・zxp を Adobe Extension Manager CC からインストールすることで試すことが可能です。

・ファイル構成

- EmbedMetaData
	- metadata_variables.txt < メタデータの変数を指定するためのテキスト
	- EmbedMetaData.as < SWFPanelのメインクラス
	- YuruHereDoc.as < テキストの中に変数を埋め込むためのクラス
	- Panel < SWFPanelのflashファイル

- EmbedMetaData.swf < SWFPanel
- EmbedMetaData.zxp < インストーラー

・zxp展開後のファイル構成

http://help.adobe.com/ja_JP/flash/cs/extend/WS5b3ccc516d4fbf351e63e3d118a9024f3f-7fe8CS5.html

Windows 7,8 > ¥Users¥{ユーザー名}¥AppData¥Local\Adobe¥Flash CC¥language¥Configuration¥
Mac OS X > /Macintosh HD/Users/{ユーザー名}/Library/Application Support/Adobe/Flash CC/language/Configuration/

- EmbedMetaData.swf
- EmbedMetaData/metadata_variables.txt

埋め込む変数を変更したい場合は EmbedMetaData/metadata_variables.txt を修正してください。

