/**
 * @namespace SampleJS
 * @type {Object}
 */
var SampleJS = {};