this.SampleJS = this.SampleJS || {};

(function() {
	/**
	 * BlurFilterクラスを使用すると、表示オブジェクトにぼかし効果を適用できます。ぼかし効果とは、曇りガラスのようにぼやっとぼけている効果です。結果として得られるイメージが最大サイズを超えると、フィルターは適用されません。
	 *
	 * @constructor
	 * @memberof SampleJS
	 */
	function BlurFilter() {}

	BlurFilter.prototype = {

		/**
		 * 対象オブジェクトにぼかし効果を適応します。blurX、blurYの値が大きくなるほどぼやけ具合も強くなります。
		 *
		 * @method
		 * @name SampleJS.BlurFilter#add
		 * @param	{Object}	target	フィルターを適応したいオブジェクト
		 * @param	{Number}	blurX	水平方向へのぼかし量
		 * @param	{Number}	blurY	垂直方向へのぼかし量
		 */
		add: function(target, blurX, blurY) {

		},

		/**
		 * 対象オブジェクトからぼかし効果を除去します。
		 *
		 * @method
		 * @name SampleJS.BlurFilter#remove
		 * @param	{Object}	target	フィルターを適応したいオブジェクト
		 */
		remove: function(target) {

		}
	};

	this.SampleJS.BlurFilter = BlurFilter;
}());