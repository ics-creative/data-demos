this.SampleJS = this.SampleJS || {};

(function() {

	/**
	 * Loaderクラスは、外部にあるファイルを読み込むために使用します。読み込みを開始するにはload()メソッドを使用します。
	 *
	 * @constructor
	 * @memberof SampleJS
	 */
	function Loader() {}

	Loader.prototype = {
		/**
		 * 外部にあるファイルの読み込みを行います。
		 *
		 * @method
		 * @name SampleJS.Loader#load
		 * @param	{String}	url		読み込みたいURL
		 * @param	{Object}	params	APIへ渡すパラメーター
		 * @returns {Object}	読み込んだオブジェクト
		 */
		load: function(url, params) {
			return {}
		}
	};

	this.SampleJS.Loader = Loader;
}());